<?php

namespace Drupal\employee\Controller;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;


class EmployeeController {
public function listEmployee() {

    $header_row = array(
        'id' => t('Id'),
        'name' => t('Name'),
        'mail' => t('Mail'),
        'gender' => t('Gender'),
        'title' => t('Title'),
        'department' => t('Department'),
        'mobile' => t('Mobile'),
        'address' => t('Address'),
        'zipcode' => t('Zipcode'),
    );

    $connection = \Drupal::database();
	$query = $connection->select('employee','emp')
    ->fields('emp', ['id', 'name', 'mail', 'gender','title','department','mobile','address','zipcode']);
    $pager = $query->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(5);
    $result = $pager->execute()->fetchAll();
    $rows=array();
    foreach ($result as $rec) {
        $edit   = Url::fromUserInput('/registration?num='.$rec->id);
        $delete   = Url::fromUserInput('/delete?num='.$rec->id);
    	 $rows[] = array(   
            'id' => $rec->id,
            'name' => $rec->name,
            'mail' => $rec->mail,
            'gender' => $rec->gender,
            'title' => $rec->title,
            'department'=> $rec->department,
            'mobile' => $rec->mobile,
            'address' => $rec->address,
            'zipcode' => $rec->zipcode,
            \Drupal::l('Edit', $edit),
            \Drupal::l('Delete', $delete),
            );
        }

        $form['table'] = [
            '#type' => 'table',
            '#header' => $header_row,
            '#rows' => $rows,
        ]; 
        $form['pager'] = array(
            '#type' => 'pager'
        ); 
        return $form;   
    }

    public function deleteEmployee() {
        $get_num_del = \Drupal::request()->query->get('num');
        $connection = \Drupal::database();
        $deletequery = $connection->delete('employee')
        ->condition('id', $get_num_del)
        ->execute();
        $url = Url::fromRoute('employee.registration');
         return array(
                '#title' => 'Deleted Successfully!  ',
                '#markup' => \Drupal::l('Click to register again', $url ),
            );

    }

}

?>