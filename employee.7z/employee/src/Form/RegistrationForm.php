<?php
namespace Drupal\employee\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Database\Database;

class RegistrationForm extends FormBase{

	public function getFormId(){
	 	return 'registration_form';
	}

	public function buildForm(array $form, FormStateInterface $form_state){

		$get_num = \Drupal::request()->query->get('num');
 		$connection = \Drupal::database();
 	    $record = array();

	    if (isset($get_num)) {
	        $connection = \Drupal::database();
			$query = $connection->select('employee','emp')
			->condition('id', $get_num)
		    ->fields('emp', ['id', 'name', 'mail', 'gender','title','department','mobile','address','zipcode']);
		    $record = $query->execute()->fetchAssoc();
	    }

		$form['emp_name']=array(
			'#type' => 'textfield',
			'#title' => t('Employee Name'),
			'#required' => TRUE,
			'#default_value' => (isset($record['name']) && $get_num) ? $record['name']:'',
		);	
		$form['emp_mail']=array(
			'#type' => 'textfield',
			'#title' => t('Email Id'),
			'#required' => TRUE,
			'#default_value' => (isset($record['mail']) && $get_num) ? $record['mail']:'',
		);
		$form['gender']=array(
			'#type' => 'select',
			'#title' => t('Gender'),
			'#options' => array(
				'Female' => t('Female'),
				'Male' => t('Male'),
			'#default_value' => (isset($record['gender']) && $get_num) ? $record['gender']:'',
			),
		);
		$form['title']=array(
			'#type' => 'textfield',
			'#title' => t('Job Title'),
			'#required' => TRUE,
			'#default_value' => (isset($record['title']) && $get_num) ? $record['title']:'',
		);
		$form['department']=array(
			'#type' => 'textfield',
			'#title' => t('Department'),
			'#required' => TRUE,
			'#default_value' => (isset($record['department']) && $get_num) ? $record['department']:'',
		);
		$form['mobile']=array(
			'#type' => 'textfield',
			'#title' => t('Mobile'),
			'#required' => TRUE,
			'#default_value' => (isset($record['mobile']) && $get_num) ? $record['mobile']:'',
		);
		$form['address']=array(
			'#type' => 'textarea',
			'#title' => t('Address'),
			'#required' => TRUE,
			'#default_value' => (isset($record['address']) && $get_num) ? $record['address']:'',
		);
		$form['zipcode']=array(
			'#type' => 'textfield',
			'#title' => t('Zipcode'),
			'#required' => TRUE,
			'#default_value' => (isset($record['zipcode']) && $get_num) ? $record['zipcode']:'',

		);
		$form['submit']=array(
			'#type'=>'submit',
			'#value'=> $this->t('Submit'),
		);
    return $form;

	}
	public function submitForm(array &$form, FormStateInterface $form_state) {
		$get_num_upd = \Drupal::request()->query->get('num');
    	$values = $form_state->getValues();
    	$employee_name = $values["emp_name"];
    	$employee_email = $values["emp_mail"];
    	$employee_gender = $values["gender"];
    	$job_title = $values["title"];
    	$employee_department = $values["department"];
    	$employee_mobile = $values["mobile"];
    	$employee_address = $values["address"];
    	$employee_zipcode = $values["zipcode"];
   		//print_r($values);
   		if($get_num_upd){

	   		$fields=array('name'=>"$employee_name",'mail'=>"$employee_email",'gender'=>"$employee_gender",'title'=>"$job_title",'department'=>"$employee_department",'mobile'=>"$employee_mobile",'address'=>"$employee_address",'zipcode'=>"$employee_zipcode",); 
			\Drupal::database()
			->update('employee')
			->condition('id', $get_num_upd)
			->fields($fields)
			->execute();
   		}
   		else{
			$fields=array('name'=>"$employee_name",'mail'=>"$employee_email",'gender'=>"$employee_gender",'title'=>"$job_title",'department'=>"$employee_department",'mobile'=>"$employee_mobile",'address'=>"$employee_address",'zipcode'=>"$employee_zipcode",); 
			\Drupal::database()
			->insert('employee')
			->fields($fields)
			->execute();
		}

		$url = Url::fromRoute('employee.display');
		$form_state->setRedirectUrl($url);
		
		
   }

}

?>